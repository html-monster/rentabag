<?php

class Ebizmarts_SagePaySuite_Block_Info_SagePayNit extends Ebizmarts_SagePaySuite_Block_Info_Suite
{

    const NIT = true;

}