<?php


class Ebizmarts_SagePaySuite_Model_Sagepaysuite_Result extends Varien_Object
{

    const SSR =Null;

}