<?php
/**
 * 3D redirect
 *
 * @category   Ebizmarts
 * @package    Ebizmarts_SagePaySuite
 * @author     Ebizmarts <info@ebizmarts.com>
 */
class Ebizmarts_SagePaySuite_Block_Checkout_Threedredirect extends Mage_Core_Block_Template
{

    const CTD = Null;

}