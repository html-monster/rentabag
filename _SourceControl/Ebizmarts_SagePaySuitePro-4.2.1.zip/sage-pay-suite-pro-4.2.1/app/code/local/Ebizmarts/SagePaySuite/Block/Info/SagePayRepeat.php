<?php

/**
 * REPEAT payments (admin) info block
 *
 * @category   Ebizmarts
 * @package    Ebizmarts_SagePaySuite
 * @author     Ebizmarts <info@ebizmarts.com>
 */

class Ebizmarts_SagePaySuite_Block_Info_SagePayRepeat extends Ebizmarts_SagePaySuite_Block_Info_Suite
{

    const REPEAT = true;

}