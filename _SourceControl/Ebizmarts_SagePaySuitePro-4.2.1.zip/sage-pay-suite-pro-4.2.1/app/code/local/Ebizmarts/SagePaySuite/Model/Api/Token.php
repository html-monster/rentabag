<?php

/**
 * Token API model
 *
 * @category    Ebizmarts
 * @package     Ebizmarts_SagePaySuite
 * @author      Ebizmarts Team <info@ebizmarts.com>
 */

class Ebizmarts_SagePaySuite_Model_Api_Token extends Ebizmarts_SagePaySuite_Model_Api_Payment
{

    const ATK = Null;

}