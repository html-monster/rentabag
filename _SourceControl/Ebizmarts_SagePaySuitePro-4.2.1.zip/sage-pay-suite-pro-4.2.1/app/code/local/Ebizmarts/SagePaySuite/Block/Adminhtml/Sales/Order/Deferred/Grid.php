<?php

class Ebizmarts_SagePaySuite_Block_Adminhtml_Sales_Order_Deferred_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('sales_order_deferred_grid');
        $this->setUseAjax(true);
        $this->setDefaultSort('created_at');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
    }

    /**
     * Retrieve collection class
     *
     * @return string
     */
    protected function _getCollectionClass()
    {
        return 'sales/order_grid_collection';
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getResourceModel($this->_getCollectionClass());
        $collection->getSelect()
        ->joinLeft(
            array('trns' => Mage::getSingleton('core/resource')->getTableName('sagepaysuite_transaction')),
            'main_table.entity_id = trns.order_id',
            'integration'
        )
        ->where('trns.tx_type = ?', 'DEFERRED')
        ->where('isnull(trns.released) OR trns.released = 0');

        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {

        $this->addColumn(
            'real_order_id', array(
            'header'=> Mage::helper('sagepaysuite')->__('Order #'),
            'width' => '80px',
            'type'  => 'text',
            'index' => 'increment_id',
            )
        );

        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn(
                'store_id', array(
                'header'    => Mage::helper('sales')->__('Purchased from (store)'),
                'index'     => 'store_id',
                'type'      => 'store',
                'store_view'=> true,
                'display_deleted' => true,
                )
            );
        }

        $this->addColumn(
            'created_at', array(
            'header' => Mage::helper('sales')->__('Purchased On'),
            'index' => 'created_at',
            'type' => 'datetime',
            'width' => '100px',
            'filter_index' => 'main_table.created_at',
            )
        );

        $this->addColumn(
            'billing_name', array(
            'header' => Mage::helper('sales')->__('Bill to Name'),
            'index' => 'billing_name',
            )
        );

        $this->addColumn(
            'shipping_name', array(
            'header' => Mage::helper('sales')->__('Ship to Name'),
            'index' => 'shipping_name',
            )
        );

        $this->addColumn(
            'base_grand_total', array(
            'header' => Mage::helper('sales')->__('G.T. (Base)'),
            'index' => 'base_grand_total',
            'type'  => 'currency',
            'currency' => 'base_currency_code',
            )
        );

        $this->addColumn(
            'grand_total', array(
            'header' => Mage::helper('sales')->__('G.T. (Purchased)'),
            'index' => 'grand_total',
            'type'  => 'currency',
            'currency' => 'order_currency_code',
            )
        );

        $this->addColumn(
            'status', array(
            'header' => Mage::helper('sales')->__('Status'),
            'index' => 'status',
            'type'  => 'options',
            'width' => '70px',
            'filter' => false,
            'options' => Mage::getSingleton('sales/order_config')->getStatuses(),
            )
        );

        $this->addColumn(
            'integration', array(
            'header' => Mage::helper('sagepaysuite')->__('Integration'),
            'index' => 'integration',
            'type'  => 'options',
            'options' => Mage::getModel('sagepaysuite/sagepaysuite_source_protocol')->toOption(),
            )
        );

        return parent::_prepareColumns();
    }

    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('entity_id');
        $this->getMassactionBlock()->setFormFieldName('order_ids');
        $this->getMassactionBlock()->setUseSelectAll(false);

        $this->getMassactionBlock()->addItem(
            'release_order', array(
             'label'=> Mage::helper('sagepaysuite')->__('Release'),
             'url'  => $this->getUrl('*/*/massRelease'),
            )
        );

        return $this;
    }

    public function getRowUrl($row)
    {
        if (Mage::getSingleton('admin/session')->isAllowed('sales/order/actions/view')) {
            return $this->getUrl('adminhtml/sales_order/view', array('order_id' => $row->getId()));
        }

        return false;
    }

    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', array('_current'=>true));
    }

}